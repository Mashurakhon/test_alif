﻿<?php
	if(isset($_POST['fname']) && isset($_POST['otype']))
	{
		if($_POST['fname']=='' || $_POST['otype']=='') die("Don't send empty parametters!");
		$fname = $_POST['fname'].".txt";
		$otype = $_POST['otype'];
		try{
			$file = file($fname);
		}catch(Exception $ex){
			die("some problem with file!");
		}
		
		$result = array(); $i=0; $nums = array();
		foreach($file as $line){
			$nums = explode(" ", $line);
			switch($otype){
				case 1:
					$result[$i++] = $nums[0] * $nums[1];
					break;
				case 2:
					$result[$i++] = $nums[0] / $nums[1];
					break;
				case 3:
					$result[$i++] = $nums[0] + $nums[1];
					break;
				case 4:
					$result[$i++] = $nums[0] - $nums[1];
					break;
			}
		}
		
		$negeative_nums = array(); $positive_nums = array();
		for($j=0; $j<count($result); $j++){
			if($result[$j]<0)
				$negeative_nums[$j] = $result[$j];
			else
				$positive_nums[$j] = $result[$j];
		}
		
		echo "<div style='float:left; width: 230px; padding 0 10px;'>
				<h3>File: adadho.txt</h3>
				<pre>";
		print_r($file);
		echo "  </pre>
			  </div>";
		
		
		
		echo "<div style='float:left; width: 230px; padding 0 10px;'>
				<h3>File: negative_nums.txt</h3>
				<pre>";
		print_r($negeative_nums);
		echo "  </pre>
			  </div>";
			  
		echo "<div style='float:left; width: 230px; padding 0 10px;'>
				<h3>File: positive_nums.txt</h3>
				<pre>";
		print_r($positive_nums);
		echo "  </pre>
			  </div>";
	}
	else
	{	
		echo "Ajax doesn't support on your browser!";
	}
?>