﻿<html>
	<head>
		<script>
			function post(fname, otype) {
				var xmlhttp = new XMLHttpRequest();	
				xmlhttp.onreadystatechange = function() {
					if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
						document.getElementById('response').innerHTML = xmlhttp.responseText;
					}
				}
				xmlhttp.open("POST", "opa.php", true);
				xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xmlhttp.send("fname=" + fname + "&otype=" + otype);
			}
		</script>
		<style>
			html, body {margin: 0; padding: 0;}
			#form {
				width: 250px;
				margin-left: 30px;
				margin-top: 15px;
				float: left;
				font-size: 13px;
			}
			#response {
				width: 750px;
				margin-left: 30px;
				margin-top: 15px;
				float: left;
			}
			input[type=text], select, textarea{
				width: 100%;
				padding: 6px 8px;
				margin: 1px 0;
				display: inline-block;
				border: 1px solid #ccc;
				border-radius: 4px;
				box-sizing: border-box;
				margin-bottom: 20px;
			}
			input[type=button] {
				width: 100%;
				background-color: #4CAF50;
				color: white;
				padding: 6px 8px;
				margin: 1px 0;
				border: none;
				border-radius: 4px;
				cursor: pointer;
			}
			input[type=button]:hover {
				background-color: #45a049;
			}
			
		</style>
	</head>
	<body>
		<div id='form'>
			<label for="kname">Имя файла:</label>
			<input type='text' name='file_name' id='fname' value='adadho'>
			<label for="uname">Тип операции:</label>
			<select name='operation_type' id='otype'>
				<option value='1'>Умножение</option>
				<option value='2'>Деление</option>
				<option value='3'>Сложение</option>
				<option value='4'>Вычитание</option>
			</select>
			<!--<input type='text' name='operation_type' id='otype'>-->
			<!--	document.getElementById("otype").options[document.getElementById("otype").selectedIndex].text	-->
			<!--<input type='button' value='insert' id='btn' onclick='post(document.getElementById("fname").value, document.getElementById("otype").value);'>-->
			<input type='button' value='Окей' id='btn' onclick='post(document.getElementById("fname").value, document.getElementById("otype").options[document.getElementById("otype").selectedIndex].value);'>
		</div>
		<div id='response'></div>
	</body>
</html>